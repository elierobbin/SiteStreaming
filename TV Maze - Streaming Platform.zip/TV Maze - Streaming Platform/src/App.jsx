import React, { useState, useEffect } from "react";
import Card from "./components/Card";
import SearchComponent from "./components/Input";
import Modal from "./components/Modal";
import FavoritesModal from "./components/FavoritesModal";
import Star from "../public/star.svg";
import "./index.css";

export default function App() {
  const [data, setData] = useState([]);
  const [selectedShow, setSelectedShow] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [favorites, setFavorites] = useState([]);
  const [isFavoritesModalOpen, setIsFavoritesModalOpen] = useState(false);

  const getApiFilm = async () => {
    try {
      const response = await fetch(
        `https://api.tvmaze.com/search/shows?q=batman`
      );
      const data = await response.json();
      console.log(data);
      setData(data.map((item) => item.show)); // Set all shows from the response
    } catch (error) {
      console.error(error);
    }
  };

  const getApiEpisodes = async (showId) => {
    try {
      const response = await fetch(
        `https://api.tvmaze.com/shows/${showId}/episodes`
      );
      const data = await response.json();
      console.log(data);
      setSelectedShow((prevShow) => ({ ...prevShow, episodes: data }));
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    getApiFilm();
  }, []);

  const handleSearch = (searchResults) => {
    setData(searchResults); // Mettez à jour l'état `data` avec les résultats de la recherche
  };

  const handleCardClick = (show) => {
    setSelectedShow(show);
    setIsModalOpen(true);
    getApiEpisodes(show.id); // Récupérez les épisodes lorsque la carte est cliquée
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedShow(null);
  };

  const handleAddToFavorites = (show) => {
    setFavorites((prevFavorites) => [...prevFavorites, show]);
  };

  const handleRemoveFavorite = (showId) => {
    setFavorites((prevFavorites) => prevFavorites.filter(show => show.id !== showId));
  };

  const handleOpenFavoritesModal = () => {
    setIsFavoritesModalOpen(true);
  };

  const handleCloseFavoritesModal = () => {
    setIsFavoritesModalOpen(false);
  };

  return (
    <div className="flex p-4 bg-darkBlue">
      <div className="flex flex-wrap gap-4">
        <div className="flex gap-8 justify-between w-full">
          <div className="flex flex-col gap-1 items-center">
            <img src={Star} alt="Favoris" />
            <button onClick={handleOpenFavoritesModal} className="text-white">
              Favoris
            </button>
          </div>
          <SearchComponent onSearch={handleSearch} />
        </div>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-5">
          {data.map((show) => (
            <div key={show.id} onClick={() => handleCardClick(show)}>
              <Card show={show} />
            </div>
          ))}
        </div>
      </div>

      <Modal
        show={selectedShow}
        onClose={handleCloseModal}
        onAddToFavorites={handleAddToFavorites}
      />

      <FavoritesModal
        isOpen={isFavoritesModalOpen}
        onClose={handleCloseFavoritesModal}
        favorites={favorites}
        onRemoveFavorite={handleRemoveFavorite}
      />
    </div>
  );
}