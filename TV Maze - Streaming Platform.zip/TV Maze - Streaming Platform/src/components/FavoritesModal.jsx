import React from "react";
import PropTypes from 'prop-types';

export default function FavoritesModal({ isOpen, onClose, favorites, onRemoveFavorite }) {
  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-blackOpacity flex items-center justify-center">
      <div className="bg-darkBlue h-modal rounded-xl mx-4 md:max-w-[850px] overflow-x-hidden overflow-auto relative no-scrollbar">

        <div className="flex flex-col gap-4 pt-12 mx-4 md:mx-12">

          <div className="flex gap-4">
            <button
              onClick={onClose}
              className="text-white text-xl z-10"
            >
              <img
                src="/public/arrow.svg"
                className="w-8 aspect-square p-2 bg-white rounded-lg"
                alt="Retour"
              />
            </button>
            <h2 className="text-white text-xl">Mes favoris</h2>
          </div>

          <div className="grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-5">
            {favorites.map((show) => (
              <div key={show.id} className="relative">
                <img src={show.image?.medium} alt={show.name} className="w-full h-auto rounded-lg" />
                <h3 className="text-white text-sm mt-2 flex justify-between items-center">
                  {show.name}
                  <button
                    onClick={() => onRemoveFavorite(show.id)}
                    className="text-white text-xl ml-2"
                  >
                    &times;
                  </button>
                </h3>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

FavoritesModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  favorites: PropTypes.arrayOf(PropTypes.object).isRequired,
  onRemoveFavorite: PropTypes.func.isRequired,
};