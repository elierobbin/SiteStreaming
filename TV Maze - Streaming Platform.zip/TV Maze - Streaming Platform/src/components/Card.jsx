import React from "react";

function Card({ show }) {
  return (
    <>
      <img
        className="rounded-lg aspect-auto object-cover"
        src={show.image.original}
        alt={show.name}
      />
    </>
  );
}

export default Card;
