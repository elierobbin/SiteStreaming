import { Input } from "@/components/ui/input";
import Search from "/public/search.svg";
import { useState } from "react";

export default function SearchComponent({ onSearch }) {
  const [input, setInput] = useState("");

  const handleSearch = () => {
    fetch(`https://api.tvmaze.com/search/shows?q=${input}`)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        onSearch(data.map((item) => item.show)); // Passez les données récupérées à la fonction de rappel
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  };

  return (
    <div className="flex w-[30%] items-center space-x-2">
      <Input
        type="search"
        className="text-white"
        placeholder="Rechercher un film, une série"
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      <span className="bg-white p-2 rounded-full" onClick={handleSearch}>
        <img src={Search} alt="Icone Recherche" />
      </span>
    </div>
  );
}