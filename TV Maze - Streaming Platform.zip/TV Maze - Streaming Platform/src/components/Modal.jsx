import React from "react";
import Badge from "./Badge";
import Button from "./Button";
import Actions from "./Actions";
import Arrow from "/public/arrow.svg";
import Shape from "/public/shapeBlur.png";

export default function Modal({ show, onClose, onAddToFavorites }) {
  if (!show) {
    return null;
  }

  const cleanSummary = show.summary
    .replace(/<\/?p>/g, "")
    .replace(/<\/?b>/g, "");

  return (
    <div className="fixed inset-0 bg-blackOpacity flex items-center justify-center">
      <div className="bg-darkBlue h-modal rounded-xl mx-4 md:max-w-[850px] overflow-x-hidden overflow-auto relative no-scrollbar z-40">
        <button
          onClick={onClose}
          className="absolute top-4 left-4 text-white text-xl z-50"
        >
          <img
            src={Arrow}
            className="w-8 aspect-square p-2 bg-white rounded-lg"
            alt="Retour"
          />
        </button>

        <div className="relative bg-red-200 h-modalCover">
          <img
            src={show.image?.medium}
            alt={show.name}
            className="absolute w-full h-full rounded-lg object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-darkBlue to-transparent"></div>
        </div>

        <div className="flex flex-col gap-4 pt-12 mx-4 md:mx-12">
          <div className="flex justify-center flex-row flex-wrap gap-1 z-20">
            <Badge show={show} />
          </div>
          <div className="flex flex-col justify-between gap-4 sm:flex-row">
            <Button>Regarder</Button>
            <Actions onAddToFavorites={() => onAddToFavorites(show)} />
          </div>

          <div className="flex flex-col gap-1 pb-8">
            <h1 className="font-bold text-lg text-white uppercase">
              {show.name}
            </h1>
            <p className="text-sm text-white leading-7">{cleanSummary}</p>
          </div>

          <div className="flex flex-col gap-1 pb-8">
            <h2 className="font-bold text-lg text-white uppercase">Episodes</h2>
            <ul className="list-disc list-inside text-white">
              {show.episodes && show.episodes.map((episode) => (
                <li key={episode.id}>
                  <strong>{episode.name}</strong> - {episode.airdate}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <img src={Shape} alt="" className="absolute bottom-1/4 right-[-50%] scale-[2] rotate-90 z-10" />
      </div>
    </div>
  );
}
