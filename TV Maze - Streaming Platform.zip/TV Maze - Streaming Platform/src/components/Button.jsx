import React from "react";
import Play from "/public/Play.svg";

function Button() {

  return (
    <>
        <button className="flex gap-5 justify-center items-center text-white px-4 py-3 font-semibold bg-lightBlue hover:bg-lightBlueHover rounded-lg w-full">
            <img src={Play} alt="Icone Play" />
            Regarder
        </button>
    </>
  );
}

export default Button;
