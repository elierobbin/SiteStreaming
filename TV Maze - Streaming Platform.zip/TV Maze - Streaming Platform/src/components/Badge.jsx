import React from "react";

function Badge({ show }) {
  const premieredYear = new Date(show.premiered).getFullYear();

  return (
    <>
      <span className="text-black px-[6px] py-[4px] text-xs font-semibold bg-lightBlue rounded-[2px]">
        {premieredYear}
      </span>
      {show.genres.map((genre, index) => (
        <span
          key={index}
          className="text-lightBlue px-[6px] py-[4px] text-xs font-semibold bg-black rounded-[2px]"
        >
          {genre}
        </span>
      ))}
      <span className="text-black px-[6px] py-[4px] text-xs font-semibold bg-yellow rounded-[2px]">
        {show.rating.average}/10
      </span>
    </>
  );
}

export default Badge;
