import React from "react";
import Download from "/public/download.svg";
import Star from "/public/star.svg";
import StarPleine from "/public/star-pleine.svg";

function Actions({ onAddToFavorites }) {
  const [isFavorite, setIsFavorite] = React.useState(false);

  const handleAddToFavorites = () => {
    setIsFavorite(!isFavorite);
    onAddToFavorites();
  };

  return (
    <div className="flex gap-[1.5rem] justify-around">
      <button className="flex flex-col gap-2 justify-center items-center text-[12px] z-20 text-white whitespace-nowrap">
        <img src={Download} className="w-4 aspect-auto" alt="Icone Download" />
        Télécharger
      </button>

      <button
        className="flex flex-col gap-2 justify-center items-center text-[12px] z-20 text-white whitespace-nowrap"
        onClick={handleAddToFavorites}
      >
        <img src={isFavorite ? StarPleine : Star} className="w-4 aspect-auto" alt="Icone Star" />
        {isFavorite ? "Retirer des favoris" : "Ajouter aux favoris"}
      </button>
    </div>
  );
}

export default Actions;